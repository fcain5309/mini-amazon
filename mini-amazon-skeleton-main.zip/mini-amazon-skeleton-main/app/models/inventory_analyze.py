from flask import current_app as app

class Product_Rank:
    def __init__(self, product_id, product_name, count):
        self.product_id = product_id
        self.product_name = product_name
        self.count = count

    @staticmethod
    def top_ten_products(sid):
        rows = app.db.execute('''
        SELECT Order_Content.id AS product_id, Products.name AS product_name, SUM(Order_Content.quantity) AS count
        FROM Order_Content, Products, Specific_Order 
        WHERE Order_Content.id = Products.id
        AND Specific_Order.uid=:sid
        GROUP BY Order_Content.id, product_name
        ORDER BY count DESC
        LIMIT 10
        ''',
        sid=sid)
        return [Product_Rank(*row) for row in rows]

    @staticmethod
    def worst_ten_products(sid):
        rows = app.db.execute('''
        SELECT Order_Content.id AS product_id, Products.name AS product_name, SUM(Order_Content.quantity) AS count
        FROM Order_Content, Products, Specific_Order
        WHERE Order_Content.id = Products.id
        AND Specific_Order.uid=:sid
        GROUP BY Order_Content.id, product_name
        ORDER BY count ASC
        LIMIT 10
        ''',
        sid=sid)
        return [Product_Rank(*row) for row in rows]

    @staticmethod
    def lowest_ten_products(sid):
        rows = app.db.execute('''
        SELECT Inventory.pid AS product_id, Products.name AS product_name, SUM(Inventory.quantity) AS count
        FROM Inventory, Products 
        WHERE Inventory.pid = Products.id
        AND Inventory.uid=:sid
        GROUP BY product_id, product_name
        ORDER BY count ASC
        LIMIT 10
        ''',
        sid=sid)
        return [Product_Rank(*row) for row in rows]
