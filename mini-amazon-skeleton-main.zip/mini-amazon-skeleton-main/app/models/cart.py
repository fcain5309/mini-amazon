from flask import current_app as app

from flask_login import current_user

from datetime import datetime

class Cart:
    """
    This is just a TEMPLATE for Cart, you should change this by adding or 
        replacing new columns, etc. for your design.
    """
    def __init__(self, id, buy_uid, inventory_id, quant, prod_status):
        self.id = id
        self.buy_uid = buy_uid
        self.inventory_id = inventory_id
        self.quant = quant
        self.prod_status = prod_status

    # this function allows a user to add a product to their cart
    @staticmethod
    def add_to_cart(buyer_id, seller_id, inv_id, pid, quantity):
        try:
            rows = app.db.execute("""
INSERT INTO Cart(buy_uid, sell_uid, inventory_id, pid, quant, prod_status)
VALUES(:buyer_id, :seller_id, :inv_id, :pid, :quantity, :status)
""",
                                  buyer_id=buyer_id,
                                  seller_id=seller_id,
                                  inv_id=inv_id,
                                  pid=pid,
                                  quantity=quantity,
                                  status = "in_cart")
        except Exception as e:
            # likely email already in use; better error checking and reporting needed;
            # the following simply prints the error to the console:
            print(str(e))
            return None


# this method allows a user to remove an item from cart from their cart
    @staticmethod
    def delete_item_from_cart(uid, pid, sell_uid):
        rows = app.db.execute('''
DELETE FROM Cart 
WHERE buy_uid = :uid AND pid = :pid AND sell_uid = :sell_uid
''',
                              uid=current_user.id, pid=pid, sell_uid=sell_uid)
        return rows

# this method helps users switch the status of items (in cart  vs moving save for later)
    @staticmethod
    def move_to_cart(uid, pid, sell_uid):
        curr_status_raw = app.db.execute('''SELECT prod_status FROM Cart WHERE  buy_uid = :uid AND pid = :pid AND sell_uid = :sell_uid''',
        uid=current_user.id, pid=pid, sell_uid=sell_uid)
        curr_status = str(curr_status_raw[0][0])
        if curr_status == 'save_for_later':
            status = 'in_cart'
        elif curr_status == 'in_cart':
            status = 'save_for_later'
        rows = app.db.execute('''
UPDATE Cart 
SET prod_status = :status
WHERE buy_uid = :uid AND pid = :pid AND sell_uid = :sell_uid
''',
                              uid=current_user.id, pid=pid, sell_uid=sell_uid, status=status)
        return rows

# this method allows a user to update the quantity of a product in their cart
    @staticmethod
    def update_cart_quant(uid, quant, pid):
        rows = app.db.execute('''
UPDATE Cart 
Set quant = :quant
WHERE buy_uid = :uid AND pid = :pid
''',
                              uid=current_user.id, quant=quant, pid=pid)
        return rows

#  Given a user id, find the items in the cart for that user. Allows for display of cart items.
    @staticmethod
    def get_items_for_user(buy_uid):
        rows = app.db.execute(''' 
SELECT c.id, Products.price AS unit_price, (Products.price * c.quant) AS total_price, c.buy_uid, c.sell_uid, c.pid, c.quant, c.prod_status, Products.name, u.firstname, u.lastname
FROM Cart c
INNER JOIN Products
ON (c.pid = Products.id)
INNER JOIN Users u
ON c.sell_uid = u.id
WHERE c.buy_uid = :buy_uid
''',
                                buy_uid = current_user.id)
        return rows

# get only product list so that users can select which product(s) from their cart to update quantity of
    @staticmethod
    def only_prods(buy_uid):
        rows = app.db.execute(''' 
SELECT Products.id, Products.name
FROM Cart c
INNER JOIN Products
ON (c.pid = Products.id)
WHERE c.buy_uid = :buy_uid
''',
                                buy_uid = current_user.id)
        return rows
    
# this method displays the order contents for detailed order page
    
    @staticmethod
    def order_content_page(oid):
        rows = app.db.execute(''' 
SELECT O.order_id AS order_id, I.uid AS seller_id, P.id as product_id, P.name, P.price AS current_price, O.quantity, O.price AS purchased_price, (O.price * O.quantity) AS total_price, O.status,
    U.firstname AS seller_firstname, U.lastname AS seller_lastname
FROM Order_Content O
INNER JOIN Inventory I ON (O.inventory_id = I.id)
INNER JOIN Products P ON (I.pid = P.id)
INNER JOIN Users U ON (I.uid = U.id)
WHERE O.order_id = :oid
''',
                                oid = oid)
        return rows

    
# this method obtains the buyer id for a certain order
    @staticmethod
    def get_order_buyer(oid):
        rows = app.db.execute('''SELECT uid FROM Specific_Order WHERE id = :oid''', oid=oid)
        return rows


#  Submit an Order
    @staticmethod
    def order_submission():
        prod_status = "in_cart"
        # obtain the total cost of the order
        total_price_raw = app.db.execute('''
        SELECT SUM(Products.price * c.quant) 
        FROM Cart c, Products 
        WHERE c.buy_uid = :buy_uid AND c.prod_status = :prod_status AND Products.id = c.pid ''',
                                buy_uid = current_user.id, prod_status=prod_status)
        
        if total_price_raw[0][0] is None:
            return ["Nothing in Cart"]
        else:
            total_price = float(total_price_raw[0][0])
       
        # verify buyer balance
        curr_amount_raw = app.db.execute('''SELECT amount FROM Users WHERE id = :buy_uid''', buy_uid= current_user.id)
        curr_amount = float(curr_amount_raw[0][0])

        if curr_amount < total_price:
            return ["Insufficient Balance"]
        else:
            # verify that the seller has sufficient inventory
            inventory_ids_raw = list(app.db.execute('''SELECT inventory_id FROM Cart WHERE buy_uid = :buy_uid AND prod_status = 'in_cart' ''',
                                    buy_uid = current_user.id))
            inv_list = []
            for k in range(len(inventory_ids_raw)):
                inv_list.append(float(inventory_ids_raw[k][0]))
            
            for i in inv_list:
                quant_raw = app.db.execute('''SELECT quant FROM Cart WHERE buy_uid = :buy_uid AND prod_status = 'in_cart' AND inventory_id =:id ''',
                                    buy_uid = current_user.id, id=i)
                quant = float(quant_raw[0][0])
                seller_quant_raw = app.db.execute('''SELECT quantity FROM Inventory WHERE id = :id ''', id=i)
                seller_quant = seller_quant_raw[0][0]
                product_raw_name = app.db.execute(''' SELECT P.name FROM Products P INNER JOIN Inventory I ON (I.pid = P.id) AND
                                                 I.id = :id''', id=i)
                product_name = str(product_raw_name[0][0])

                if seller_quant < quant:
                    string_ret = ["Out of Stock Item:", product_name]
                    print("string_ret:", string_ret, "string_ret[0]:",string_ret[0])
                    return string_ret

            # adding to the user's order to specific order, this auto updates buyer balance via trigger
            # if we reach here, this means that there is sufficient inventory AND balance
            status = "in progress"                        
            app.db.execute('''INSERT INTO Specific_Order (uid, total_price, time_stamp, status) VALUES (:buy_uid, :total_price, :time_stamp, :status)''',
                                    buy_uid = current_user.id, total_price=total_price, status=status, time_stamp=datetime.now().isoformat(sep=" ", timespec="seconds"))
            
            # getting the correct order id to update order contents
            order_raw = app.db.execute('''SELECT id FROM Specific_Order
                                                    ORDER BY id DESC
                                                    LIMIT 1''')
            my_order = float(order_raw[0][0])
            
            # updating order contents table with items from cart
            for i in inv_list:
                quant_raw = app.db.execute('''SELECT quant FROM Cart WHERE buy_uid = :buy_uid AND prod_status = 'in_cart' AND inventory_id =:id ''',
                                    buy_uid = current_user.id, id=i)
                quant = float(quant_raw[0][0])
                
                # calculates the price to insert into order contents
                prod_price_raw = app.db.execute ('''SELECT  (Products.price * c.quant) AS prod_price
                FROM Cart c
                INNER JOIN Products
                ON (c.pid = Products.id)
                WHERE c.buy_uid = :buy_uid ''', buy_uid = current_user.id)
                prod_price = float(prod_price_raw[0][0])
                
                # adding info to order-content, this should update seller balance via trigger
                app.db.execute('''INSERT INTO Order_Content (order_id, inventory_id, quantity, price, status) VALUES (:oid, 
                                :inv_id, :quant, :price, :status)''',
                                    oid = my_order,
                                    inv_id = i,
                                    quant = quant,
                                    price = prod_price,
                                    status = status)

                # updating seller inventory
                seller_quant_raw = app.db.execute('''SELECT quantity FROM Inventory WHERE id = :id ''', id=i)
                seller_quant = seller_quant_raw[0][0]
                new_quant = seller_quant - quant
                update_inv_raw = app.db.execute('''UPDATE Inventory
                                        SET quantity = :quant WHERE id=:inv_id''', quant = new_quant, inv_id=i)              
                
            
                # now we want to output our order, which has the order contents updated so that output is right
                rows = app.db.execute(''' 
            SELECT P.name AS product, O.price 
            FROM Order_Content O
            INNER JOIN Inventory I ON (O.inventory_id = I.id)
            INNER JOIN Products P ON (I.pid = P.id)
            WHERE O.order_id = :oid
            ''',
                                        oid = my_order)
                
            # all validations theoretically done so we now clear the cart
            app.db.execute('''DELETE FROM Cart WHERE buy_uid = :buy_uid AND prod_status = 'in_cart' ''', buy_uid = current_user.id)

            return rows
        