from flask import current_app as app
from .order_content import Order_Content

#Product Review Class
class Product_Review:
    """
    This is just a TEMPLATE for Review, you should change this by adding or 
        replacing new columns, etc. for your design.
    """
    def __init__(self, uid, pid, review_time, review_content):
        self.uid = uid
        self.pid = pid
        self.review_time = review_time
        self.review_content = review_content

#Get method
    @staticmethod
    def get(uid, pid):
        rows = app.db.execute('''
SELECT uid, pid, review_time, review_content
FROM Product_Review
WHERE uid = :uid AND pid = :pid
''',
                              uid=uid,
                              pid=pid)
        return Product_Review(*(rows[0])) if rows else None
        
#Getting all Product reviews by the pid.
    @staticmethod
    def get_by_pid(pid):
        rows = app.db.execute('''
SELECT uid, pid, review_time, review_content
FROM Product_Review
WHERE pid = :pid
''',
                              pid=pid)
        return [Product_Review(*row) for row in rows]

#Gets all product reviews post a certain date
    @staticmethod
    def get_all_by_uid_since(uid, since):
        rows = app.db.execute('''
SELECT uid, pid, review_time, review_content
FROM Product_Review
WHERE uid = :uid
AND review_time >= :since
ORDER BY review_time DESC
''',
                              uid=uid,
                              since=since)
        return [Product_Review(*row) for row in rows]

#Method to deterime if you have already bought a product!
    @staticmethod
    def has_purchased_product(uid,pid):
        rows = app.db.execute('''
WITH join_order_contents
AS (SELECT order_id, Specific_Order.uid AS uid, time_stamp, Inventory.uid AS seller_uid, name, Order_Content.quantity, Order_Content.price
FROM Order_Content
INNER JOIN Specific_Order
ON (Order_Content.order_id = Specific_Order.id)
INNER JOIN Inventory
ON (Inventory.id = Order_Content.inventory_id)
INNER JOIN Products
ON (Inventory.pid = Products.id AND Inventory.pid = :pid))
SELECT *
FROM join_order_contents
WHERE (join_order_contents.uid = :uid)
ORDER BY time_stamp DESC
''',
                              uid=uid,
                              pid=pid)
        return rows if rows else None

#Method to determine if you've already reviewed
    @staticmethod
    def has_already_reviewed(uid,pid):
        rows = app.db.execute('''
SELECT * 
FROM Product_Review
WHERE uid = :uid AND pid= :pid
''',
                              uid=uid,
                              pid=pid)
        return rows if rows else None

#Have already purchased from seller check method
    @staticmethod
    def has_purchased_from_seller(uid,sid):
        rows = app.db.execute('''
WITH join_order_contents
AS (SELECT order_id, Specific_Order.uid AS uid, time_stamp, Inventory.uid AS seller_uid, name, Order_Content.quantity, Order_Content.price
FROM Order_Content
INNER JOIN Specific_Order
ON (Order_Content.order_id = Specific_Order.id)
INNER JOIN Inventory
ON (Inventory.id = Order_Content.inventory_id)
INNER JOIN Products
ON (Inventory.pid = Products.id AND Inventory.uid = :sid))
SELECT *
FROM join_order_contents
WHERE (join_order_contents.uid = :uid)
ORDER BY time_stamp DESC
''',
                              uid=uid,
                              sid=sid)
        return rows if rows else None


#Gets all the purchases from a certain user
    @staticmethod
    def get_all_purchases_by_uid(uid):
        rows = app.db.execute('''
WITH join_order_contents
AS (SELECT order_id, Specific_Order.uid AS uid, Inventory.pid AS pid, time_stamp, Inventory.uid AS seller_uid, name AS name, Order_Content.quantity, Order_Content.price
FROM Order_Content
INNER JOIN Specific_Order
ON (Order_Content.order_id = Specific_Order.id)
INNER JOIN Inventory
ON (Inventory.id = Order_Content.inventory_id)
INNER JOIN Products
ON (Inventory.pid = Products.id))
SELECT *
FROM join_order_contents
WHERE (join_order_contents.uid = :uid)
ORDER BY time_stamp DESC
''',
                              uid=uid)
        return rows if rows else None

#Returns the name of ther person making a review based upon pid and uid
    @staticmethod
    def get_name_by_pid_and_uid(uid,pd):
        rows = app.db.execute('''
WITH join_order_contents
AS (SELECT order_id, Specific_Order.uid AS uid, Inventory.pid AS pid, time_stamp, Inventory.uid AS seller_uid, name AS name, Order_Content.quantity, Order_Content.price
FROM Order_Content
INNER JOIN Specific_Order
ON (Order_Content.order_id = Specific_Order.id)
INNER JOIN Inventory
ON (Inventory.id = Order_Content.inventory_id)
INNER JOIN Products
ON (Inventory.pid = Products.id AND Inventory.pid = :pd))
SELECT name
FROM join_order_contents
WHERE (join_order_contents.uid = :uid)
ORDER BY time_stamp DESC
''',
                              uid=uid,
                              pd = pd)
        return rows if rows else None

#Gets all reveiw information
    @staticmethod
    def get_all_by_uid(uid):
        rows = app.db.execute('''
SELECT uid, pid, review_time, review_content
FROM Product_Review
WHERE uid = :uid
ORDER BY review_time DESC
''',
                              uid=uid)
        return [Product_Review(*row) for row in rows]
#makes a product review
    @staticmethod
    def register_product_review(uid, pid, review_time, review_content):
        try:
            rows = app.db.execute("""
INSERT INTO Product_Review(uid, pid, review_time, review_content)
VALUES(:uid, :pid, :review_time, :review_content)
RETURNING id
""",
                                  uid=uid,
                                  pid=pid,
                                  review_time=review_time,
                                  review_content=review_content
                                  )
            id1 = rows[0][0]
            id2 = rows[1][0]
            return Product_Review.get(id1,id2)
        except Exception as e:
            # likely email already in use; better error checking and reporting needed;
            # the following simply prints the error to the console:
            print(str(e))
            return None
#Makes a seller review
    @staticmethod
    def register_seller_review(uid, uid2, review_time, review_content):
        try:
            rows = app.db.execute("""
INSERT INTO Seller_Review(uid, uid2, review_time, review_content)
VALUES(:uid, :uid2, :review_time, :review_content)
RETURNING uid, uid2
""",
                                  uid=uid,
                                  uid2=uid2,
                                  review_time=review_time,
                                  review_content=review_content
                                  )
            id1 = rows[0][0]
            id2 = rows[1][0]
            return Seller_Review.get(id1,id2)
        except Exception as e:
            # likely email already in use; better error checking and reporting needed;
            # the following simply prints the error to the console:
            print(str(e))
            return None

    @staticmethod
#Delete a product Review
    def delete_product_review(uid, pid):
        try:
            rows = app.db.execute("""
DELETE FROM Product_Review
WHERE uid = :uid
AND pid = :pid
""",
                                  uid=uid,
                                  pid=pid

                                  )

            return rows
        except Exception as e:
            # likely email already in use; better error checking and reporting needed;
            # the following simply prints the error to the console:
            print(str(e))
            return None

#Edit a Product Review
    @staticmethod
    def edit_product_review(uid, pid,review_time,review_content):
        try:
            rows = app.db.execute("""
UPDATE Product_Review
SET review_time = :review_time,
review_content= :review_content
WHERE uid = :uid
AND pid = :pid
""",
                                  uid=uid,
                                  pid=pid,
                                  review_time = review_time,
                                  review_content= review_content

                                  )

            return rows
        except Exception as e:
            # likely email already in use; better error checking and reporting needed;
            # the following simply prints the error to the console:
            print(str(e))
            return None




#Seller Review class
class Seller_Review:
    """
    This is just a TEMPLATE for Review, you should change this by adding or 
        replacing new columns, etc. for your design.
    """
    def __init__(self, uid, uid2, review_time, review_content):
        self.uid = uid
        self.uid2 = uid2
        self.review_time = review_time
        self.review_content = review_content

#Basic get query
    @staticmethod
    def get(uid, uid2):
        rows = app.db.execute('''
SELECT uid, uid2, review_time, review_content
FROM Seller_Review
WHERE uid = :uid AND uid2 = :uid2
''',
                              uid=uid,
                              uid2=uid2)
        return Seller_Review(*(rows[0])) if rows else None


#Get all of seller reveiws post a certain date
    @staticmethod
    def get_all_by_uid_since(uid, since):
        rows = app.db.execute('''
SELECT uid, uid2, review_time, review_content
FROM Seller_Review
WHERE uid = :uid
AND review_time >= :since
ORDER BY review_time DESC
''',
                              uid=uid,
                              since=since)
        return [Seller_Review(*row) for row in rows]

#Checks if already have a seller review
    @staticmethod
    def has_already_reviewed(uid,sid):
        rows = app.db.execute('''
SELECT * 
FROM Seller_Review
WHERE uid = :uid AND uid2= :sid
''',
                              uid=uid,
                              sid=sid)
        return rows if rows else None
        #If returns none, then you havent reviewed



#Get all by uid gets all seller reviews by uid

    @staticmethod
    def get_all_by_uid(uid):
        rows = app.db.execute('''
SELECT uid, uid2, review_time, review_content
FROM Seller_Review
WHERE uid = :uid
ORDER BY review_time DESC
''',
                              uid=uid)
        return [Seller_Review(*row) for row in rows]

#makes a seller review
    @staticmethod
    def register_seller_review(uid, uid2, review_time, review_content):
        try:
            rows = app.db.execute("""
INSERT INTO Seller_Review(uid, uid2, review_time, review_content)
VALUES(:uid, :uid2, :review_time, :review_content)
RETURNING uid, uid2
""",
                                  uid=uid,
                                  uid2=uid2,
                                  review_time=review_time,
                                  review_content=review_content
                                  )
            id1 = rows[0][0]
            id2 = rows[1][0]
            return Seller_Review.get(id1,id2)
        except Exception as e:
            # likely email already in use; better error checking and reporting needed;
            # the following simply prints the error to the console:
            print(str(e))
            return None

#Removes a seller review
    @staticmethod
    def delete_seller_review(uid, uid2):
        try:
            rows = app.db.execute("""
DELETE FROM Seller_Review
WHERE uid = :uid
AND uid2 = :uid2
""",
                                  uid=uid,
                                  uid2=uid2

                                  )

            return rows
        except Exception as e:
            # likely email already in use; better error checking and reporting needed;
            # the following simply prints the error to the console:
            print(str(e))
            return None

#Changes a seller review
    @staticmethod
    def edit_seller_review(uid, uid2,review_time,review_content):
        try:
            rows = app.db.execute("""
UPDATE Seller_Review
SET review_time = :review_time,
review_content= :review_content
WHERE uid = :uid
AND uid2 = :uid2
""",
                                  uid=uid,
                                  uid2=uid2,
                                  review_time = review_time,
                                  review_content= review_content

                                  )

            return rows
        except Exception as e:
            # likely email already in use; better error checking and reporting needed;
            # the following simply prints the error to the console:
            print(str(e))
            return None

#Edit a seller review
    @staticmethod
    def update_seller_review(uid, uid2, review_time, review_content):
        try:
            rows = app.db.execute("""
UPDATE Seller_Review
SET review_content = :review_content,
    review_time = :review_time,
WHERE uid = :uid
AND uid2 = :uid2
""",
                                  uid=uid,
                                  uid2=uid2,
                                  review_content=review_content,
                                  review_time=review_time

                                  )

            return rows
        except Exception as e:
            # likely email already in use; better error checking and reporting needed;
            # the following simply prints the error to the console:
            print(str(e))
            return None

#Gets seller information (last name first name etc.)
    @staticmethod
    def get_all_about_seller(seller_uid):
        rows = app.db.execute('''
SELECT uid, uid2, review_time, review_content, Users.firstname AS buyer_firstname, Users.lastname AS buyer_lastname
FROM Seller_Review
JOIN Users
ON (uid = Users.id)
WHERE uid2 = :seller_uid
ORDER BY review_time DESC
''',
                              seller_uid=seller_uid)
        return rows

#Gets the average seller rating.
    @staticmethod
    def get_seller_avg(seller_uid):
        rows = app.db.execute('''
SELECT AVG(review_content)
FROM Seller_Review
WHERE uid2 = :seller_uid
''',
                              seller_uid=seller_uid)
        if rows[0][0] is None:
            ret = None
        else:
            ret = round(rows[0][0], 2)
        return ret