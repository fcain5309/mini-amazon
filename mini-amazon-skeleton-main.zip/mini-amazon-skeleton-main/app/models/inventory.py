from flask import current_app as app
#from pyspark import T


class Inventory:
    """
    This is just a TEMPLATE for Inventory, you should change this by adding or 
        replacing new columns, etc. for your design.
    """
    def __init__(self, id, uid, pid, quantity, is_active=None):
        self.id = id
        self.uid = uid
        self.pid = pid
        self.quantity = quantity
        self.is_active = is_active

    # get all inventory information using pid-- gets all possible sellers for a product
    @staticmethod
    def get_by_pid(pid):
        rows = app.db.execute('''
            SELECT *
            FROM Inventory
            WHERE pid = :pid
            ''',
                              pid=pid)
        return [Inventory(*row) for row in rows]

    # get all inventory related to a seller and a product and join with user so we can display seller name
    @staticmethod
    def get_seller_name(pid, uid):
        rows = app.db.execute('''
            SELECT i.pid, i.uid, i.quantity, u.firstname, u.lastname
            FROM Inventory i
            LEFT JOIN Users u
            ON u.id = :uid
            WHERE i.pid = :pid AND i.uid = :uid
            ''',
                              pid=pid,
                              uid=uid)
        return Inventory(*(rows[0])) if rows is not None else None

    # get all inventory related to a seller (using uid)
    @staticmethod
    def get_by_uid(uid):
        rows = app.db.execute('''
WITH join_inventory
AS (SELECT p.*, Inventory.uid AS uid, Inventory.quantity AS quantity, Inventory.pid as pid
FROM Products p
INNER JOIN Inventory
ON (Inventory.pid = p.id))
SELECT *
FROM join_inventory
WHERE (join_inventory.uid = :uid)
''',
                              uid=uid)
        return rows if rows else None

    # get all inventory
    @staticmethod
    def get_all():
        rows = app.db.execute('''
            SELECT *
            FROM Inventory
            ''')
        #return [Inventory(*row) for row in rows]
        return Inventory(*(rows[0])) if rows else None

    # pair a new seller (uid) and product (pid)-- only existing products and sellers
    @staticmethod
    def add_existing_product(pid, uid, quantity):
        try:
            rows = app.db.execute('''
                INSERT INTO Inventory(pid, uid, quantity, is_active)
                VALUES(:pid, :uid, :quantity, 1)
            ''',
                                pid=pid,
                                uid=uid,
                                quantity=quantity)
        except Exception:
            rows = None
        if rows:
            return True
        else:
            return False

    # update quantity of a given inventory
    @staticmethod
    def change_quantity(pid, uid, quantity):
        rows = app.db.execute('''
            UPDATE Inventory
            SET quantity = :quantity
            WHERE pid = :pid
            AND uid = :uid
        ''',
                              pid=pid,
                              uid=uid,
                              quantity=quantity)
        if rows:
            return True
        else:
            return False

    # get all inventory information for a given product (pid) and seller (uid)
    @staticmethod
    def get_inventory_id(uid, pid):
        rows = app.db.execute('''
            SELECT *
            FROM Inventory
            WHERE pid = :pid
            AND uid = :uid
            ''',
                              pid=pid,
                              uid=uid)
        return Inventory(*(rows[0])) if rows is not None else None

    # deactivate inventory related to one product and one user by setting is_active = 0 and quantity = 0
    @staticmethod
    def deactivate_inventory(uid, pid):
        rows = app.db.execute('''
            UPDATE Inventory
            SET quantity = 0, is_active = 0
            WHERE pid = :pid
            AND uid = :uid
            ''',
                              pid=pid,
                              uid=uid)
        
        if rows:
            return True
        else:
            return False

    # reactivate inventory related to one seller and one product by setting is_active = 1
    @staticmethod
    def reactivate_inventory(uid, pid):
        rows = app.db.execute('''
            UPDATE Inventory
            SET is_active = 1
            WHERE pid = :pid
            AND uid = :uid
            ''',
                              pid=pid,
                              uid=uid)
        
        if rows:
            return True
        else:
            return False

                     