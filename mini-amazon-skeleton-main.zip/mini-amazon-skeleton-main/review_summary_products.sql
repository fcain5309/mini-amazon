select
from 
where
group by  