import datetime
from unicodedata import name
from flask import Flask, redirect, url_for, render_template, request, flash
from flask_sqlalchemy import SQLAlchemy


app = Flask(__name__)
app.secret_key = "hello"
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.sqlite3'
app.config["SQLALCHEMEY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app, session_options={"autoflush": True})

class users(db.Model):

    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    first = db.Column(db.String(100), primary_key=False)
    last = db.Column(db.String(100), primary_key=False)
    address = db.Column(db.String(100), primary_key=False)
    email = db.Column(db.String(100), primary_key=False)
    uniquething = db.Column(db.String(100), primary_key=False)

    def __init__(self, id, first,last,address,email,uniquething):
        self.id = id
        self.first = first
        self.last = last
        self.address = address
        self.email = email
        self.uniquething = uniquething


class Products_Review(db.Model):

    __tablename__ = 'prodrev'
    userid = db.Column(db.Integer, primary_key=True)
    prodid = db.Column(db.String(100), primary_key = True)
    date = db.Column(db.DateTime(timezone=False))
    rating = db.Column(db.Float)


    def __init__(self, userid,prodid,date,rating):
        self.userid = userid
        self.prodid = prodid
        self.date = date
        self.rating = rating












@app.route('/')
def initial():



    user = users(id =1, first= "Jakobe",last="Bussey",address="Jakobe's house",email="j@email.com",uniquething= "dfafjoijejfo")
    db.session.add(user)

    user = users(id = 2, first= "Grady",last="Bussey",address="Grady's house",email="g@email.com",uniquething= "rqwijrojqfasjo")
    db.session.add(user)

#    db.session.commit()

    review = Products_Review(userid= 1,prodid = 1,date = datetime.datetime(2018, 6, 1),rating = 4.0)

    db.session.add(review)

    

    review = Products_Review(userid= 2,prodid = 2,date = datetime.datetime(2017, 4, 1),rating = 2.0)

    db.session.add(review)

    db.session.commit()


    print("DONE!")


    return redirect(url_for('querypage'))

@app.route("/querypage", methods = ["POST", "GET"])
def querypage():
    if request.method == "POST":
        name = request.form["nm"]
        return redirect(url_for("search",namae = name))
    else:
        return render_template("enterpage.html")

@app.route("/search_page/<namae>/")
def search(namae):
    return render_template("search_page.html",name = namae,people = users.query.all(),revie = Products_Review.query.all())


if __name__ == "__main__":
   with app.app_context():
    db.create_all() 
    app.run()


@app.teardown_appcontext
def shutdown_session(exception=None):
    db.schema.MetaData.drop_all()
    db.close()
    