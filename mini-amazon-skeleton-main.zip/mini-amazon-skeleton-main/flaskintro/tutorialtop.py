from curses import noecho
from flask import Flask, redirect, url_for

app = Flask(__name__)

@app.route("/")
def home():
	return "Hello! This is the home page <h1>HELLO</h1>"

@app.route("/mickeymouselastspouse/<neoname>/<name>")
def user(name,neoname):
	return f"Hello {name}! you are a varmit: "+neoname


@app.route("/admin")
def admin():
    return redirect(url_for("user", name="Admin!",neoname="I froget, its all fear."))  # Now we when we go to /admin we will redirect to user with the argument "Admin!"

if __name__ == "__main__":
	app.run()