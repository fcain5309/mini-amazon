from unicodedata import name
from flask import Flask, redirect, url_for, render_template, request

app = Flask(__name__)

@app.route('/')
def initial():
    return redirect(url_for('login'))

@app.route("/login", methods = ["POST", "GET"])
def login():
    if request.method == "POST":
        user = request.form["nm"]
        password = request.form["pass"]
        return redirect(url_for("user",usr = user,passw=password))
    else:
        return render_template("login.html")

@app.route("/postlogin/<usr>/<passw>")
def user(usr,passw):
    return "<h1> "+usr+"<h1/> <p>your password is: "+passw+"<p/>"


if __name__ == "__main__":
    app.run()