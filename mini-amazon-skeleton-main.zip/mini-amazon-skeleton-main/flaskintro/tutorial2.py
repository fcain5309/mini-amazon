from unicodedata import name
from flask import Flask, redirect, url_for, render_template

app = Flask(__name__)

@app.route('/')
def initial():
    return redirect(url_for('home',word = "wordgirl"))

@app.route('/home/<word>')
def home(word):
    return render_template('index.html',name = word,dingo ="bingo")

@app.route('/goodbye/')
def goodbye():
    return render_template('goodbye.html',number =5)

@app.route('/odds/')
def odds():
    return render_template('onlyodds.html',neonum = 9000)

@app.route('/neoodds/<neonumb>')
def neoodds(neonumb):
    return render_template('onlyodds.html',neonum = int(neonumb))

@app.route('/beginodd/')
def beginodd():
    return redirect(url_for("neoodds",neonumb="50"))

@app.route('/lis/')
def lis():
    return render_template('onlyodds.html',listo = ['megaman x','zero','bass','Boomer Quangar'])

if __name__ == "__main__":
    app.run()