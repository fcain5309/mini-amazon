from contextlib import redirect_stderr
from flask import Flask, redirect, url_for

app = Flask(__name__)

@app.route("/")
def home():
    #This is just HTML code in a line
    return "Hello! welcome to <h1>neo<h1> North Carolina"

@app.route("/home")
def homeo():
    #This is just HTML code in a line
    return "Oh no u found my secret base :("

@app.route("/sayhello/<name>")
def user(name):
    return "Hello "+name

@app.route("/admin")
def admin():
    return redirect(url_for("homeo"))

@app.route("/pong/<word>")
def pong(word):
    return "the name is pong, but you were in "+word

@app.route("/ping")
def ping():
    return redirect(url_for("pong", word = "ping"))



if __name__ == "__main__":
    app.run()