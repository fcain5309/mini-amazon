from doctest import FAIL_FAST
from pickle import FALSE, TRUE
from unicodedata import name
from flask import Flask, redirect, url_for, render_template, request, flash
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.secret_key = "hello"
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.sqlite3'
app.config["SQLALCHEMEY_TRACK_MODIFICATIONS"] = False


db = SQLAlchemy(app)

class users(db.Model):
    _id = db.Column("id", db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    password = db.Column(db.String(100))

    def __init__(self, name, password):
        self.name = name
        self.password = password

@app.route('/')
def initial():
    return redirect(url_for('login',redo = "FALSE"))

@app.route("/login/<redo>", methods = ["POST", "GET"])
def login(redo):
    print("REDO: "+str(redo))
    if request.method == "POST":
        user = request.form["nm"]
        password = request.form["pass"]

        found_user = users.query.filter_by(name = user).first()

        if (found_user != None):
            flash('hey that user is already here!')
            print("That's already here")
            return redirect(url_for("login",redo= "TRUE"))
            
        else:
            usr = users(user,password)
            db.session.add(usr)
            db.session.commit()

        return redirect(url_for("user",usr = user,passw=password))
    else:
        print("THIS IS THE REDO AT THE END:"+redo)
        if (redo == "TRUE"):
            print("im here!!!")
            render_template("login2.html",red= "TRUE")
        else: 
            return render_template("login2.html",red= "FALSE")

@app.route("/postlogin/<usr>/<passw>")
def user(usr,passw):
    return "<h1> "+usr+"<h1/> <p>your password is: "+passw+"<p/>"


if __name__ == "__main__":
   with app.app_context():
    db.create_all() 
    app.run()