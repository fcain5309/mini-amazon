from unicodedata import name
from flask import Flask, redirect, url_for, render_template, request, flash
from flask_sqlalchemy import SQLAlchemy
from database import db_session

app = Flask(__name__)
app.secret_key = "hello"
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.sqlite3'
app.config["SQLALCHEMEY_TRACK_MODIFICATIONS"] = False


db = database

class users(db.Model):
    _id = db.Column("id", db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    password = db.Column(db.String(100))

    def __init__(self, name, password):
        self.name = name
        self.password = password

@app.route('/')
def initial():
    return redirect(url_for('login'))

@app.route('/data')
def data():
    return render_template("data.html",people = users.query.all())

@app.route("/login", methods = ["POST", "GET"])
def login():
    if request.method == "POST":
        user = request.form["nm"]
        password = request.form["pass"]

        found_user = users.query.filter_by(name = user).first()

        if (found_user != None):
            flash('hey that user is already here!')
            print("That's already here")
            return render_template("login.html")
            
        else:
            usr = users(user,password)
            db.session.add(usr)
            db.session.commit()

        return redirect(url_for("user",usr = user,passw=password))
    else:
        return render_template("login.html")

@app.route("/postlogin/<usr>/<passw>")
def user(usr,passw):
    return "<h1> "+usr+"<h1/> <p>your password is: "+passw+"<p/>"


if __name__ == "__main__":
   with app.app_context():
    db.create_all() 
    app.run()

@app.teardown_appcontext
def shutdown_session(exception=None):
    db.close()