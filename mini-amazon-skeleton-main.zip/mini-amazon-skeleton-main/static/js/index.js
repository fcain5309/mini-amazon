document.addEventListener("DOMContentLoaded", function () {
  alert("Look Javascript works!");
});